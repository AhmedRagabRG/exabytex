import { authOptions } from "./auth-simple"

// Use the simple auth options without callbacks for getServerSession
export const serverAuthOptions = authOptions 