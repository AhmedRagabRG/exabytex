// Re-export simplified auth options to maintain compatibility
export { authOptions } from "./auth-simple"